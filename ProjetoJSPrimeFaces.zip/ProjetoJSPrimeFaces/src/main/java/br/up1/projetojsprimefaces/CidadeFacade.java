package br.up1.projetojsprimefaces;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;

@Stateless
public class CidadeFacade {


    // ENTITY MANAGER


    @PersistenceContext(unitName = "ProjetojfprimefacesPU")
    private EntityManager em;


    // BUSCAR CIDADE PELO ID


    public CidadeEntity find(Object id) {
        return em.find(CidadeEntity.class, id);
    }


    // LISTAR TODAS AS CIDADES
    // ORDENADAS PELO NOME

    public List<CidadeEntity> findAll() {

        return em.createQuery(
                "SELECT c FROM CidadeEntity c ORDER BY c.nome",
                CidadeEntity.class
        ).getResultList();
    }
}