package br.up1.projetojsprimefaces;

import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;

@FacesConverter(forClass = CidadeEntity.class)
public class CidadeControllerConverter implements Converter<CidadeEntity> {

    @Override
    public CidadeEntity getAsObject(
            FacesContext facesContext,
            UIComponent component,
            String value) {

        if (value == null || value.isEmpty()) {
            return null;
        }

        CidadeController controller =
                (CidadeController) facesContext.getApplication()
                        .getELResolver()
                        .getValue(
                                facesContext.getELContext(),
                                null,
                                "cidadeController"
                        );

        return controller.getCidade(Integer.valueOf(value));
    }

    @Override
    public String getAsString(
            FacesContext facesContext,
            UIComponent component,
            CidadeEntity object) {

        if (object == null || object.getId() == null) {
            return "";
        }

        return object.getId().toString();
    }
}