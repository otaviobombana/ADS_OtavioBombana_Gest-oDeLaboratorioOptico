package br.up1.projetojsprimefaces;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;

@Named("loginController")
@SessionScoped
public class LoginController implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    private PessoaFacade pessoaFacade;

    private String email;
    private String senha;

    private PessoaEntity usuarioLogado;

    public String entrar() {

        usuarioLogado = pessoaFacade.login(email, senha);

        if (usuarioLogado != null) {
            return "index?faces-redirect=true";
        }

        return null;
    }

    public String verificarLogin() {

        if (usuarioLogado == null) {
            return "login?faces-redirect=true";
        }

        return null;
    }

    public String sair() {

        usuarioLogado = null;
        email = null;
        senha = null;

        return "login?faces-redirect=true";
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public PessoaEntity getUsuarioLogado() {
        return usuarioLogado;
    }
}