package br.up1.projetojsprimefaces;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("cidadeController")
@ApplicationScoped
public class CidadeController implements Serializable {

    private static final long serialVersionUID = 1L;


    // FACADE


    @Inject
    private CidadeFacade cidadeFacade;


    // LISTAR CIDADES


    public List<CidadeEntity> getItems() {
        return cidadeFacade.findAll();
    }

  
    // BUSCAR CIDADE PELO ID


    public CidadeEntity getCidade(Object id) {

        if (id == null) {
            return null;
        }

        return cidadeFacade.find(id);
    }
}