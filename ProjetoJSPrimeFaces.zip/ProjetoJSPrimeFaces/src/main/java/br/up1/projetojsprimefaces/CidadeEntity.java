package br.up1.projetojsprimefaces;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.io.Serializable;

@Entity
@Table(name = "cidade")
public class CidadeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

 
    // ID


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

  
    // NOME
 

    @Column(name = "nome", nullable = false)
    private String nome;


    // UF
 

    @Column(name = "ufenum", nullable = false)
    private String ufEnum;

    // CONSTRUTOR


    public CidadeEntity() {
    }


    // GET ID


    public Integer getId() {
        return id;
    }


    // SET ID


    public void setId(Integer id) {
        this.id = id;
    }


    // GET NOME


    public String getNome() {
        return nome;
    }


    // SET NOME


    public void setNome(String nome) {
        this.nome = nome;
    }


    // GET UF


    public String getUfEnum() {
        return ufEnum;
    }


    // SET UF


    public void setUfEnum(String ufEnum) {
        this.ufEnum = ufEnum;
    }


    // EQUALS


    @Override
    public boolean equals(Object object) {

        if (!(object instanceof CidadeEntity)) {
            return false;
        }

        CidadeEntity other = (CidadeEntity) object;

        if ((this.id == null && other.id != null)
                || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }

        return true;
    }


    // HASHCODE


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

 
    // TOSTRING
  

    @Override
    public String toString() {
        return nome + " - " + ufEnum;
    }
}