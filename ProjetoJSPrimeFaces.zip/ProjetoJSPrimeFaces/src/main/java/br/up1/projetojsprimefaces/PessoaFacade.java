package br.up1.projetojsprimefaces;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class PessoaFacade extends AbstractFacade<PessoaEntity> {

    @PersistenceContext(unitName = "ProjetojfprimefacesPU")
    private EntityManager em;

    public PessoaFacade() {
        super(PessoaEntity.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<PessoaEntity> findAll() {
        return em.createQuery(
                "SELECT p FROM PessoaEntity p ORDER BY p.id",
                PessoaEntity.class
        ).getResultList();
    }

    // LOGIN
    public PessoaEntity login(String email, String senha) {

        try {
            return em.createQuery(
                    "SELECT p FROM PessoaEntity p "
                    + "WHERE p.email = :email "
                    + "AND p.senha = :senha",
                    PessoaEntity.class
            )
            .setParameter("email", email)
            .setParameter("senha", senha)
            .getSingleResult();

        } catch (Exception e) {
            return null;
        }
    }
}