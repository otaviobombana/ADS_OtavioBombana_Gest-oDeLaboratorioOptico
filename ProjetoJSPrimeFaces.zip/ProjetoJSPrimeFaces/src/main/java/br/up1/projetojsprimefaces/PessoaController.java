package br.up1.projetojsprimefaces;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Named("pessoaController")
@SessionScoped
public class PessoaController implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    private PessoaFacade pessoaFacade;

    private PessoaEntity pessoa;
    private PessoaEntity pessoaSelecionada;

    private List<PessoaEntity> pessoaList;

    private boolean editando;

    private String nomeContato;
    private String emailContato;
    private String mensagemContato;

    @PostConstruct
    public void init() {
        carregarLista();
        limpar();
    }

    public void carregarLista() {
        pessoaList = pessoaFacade.findAll();
    }

    public List<PessoaEntity> getPessoaList() {
        return pessoaList;
    }

    public List<PessoaEntity> getItems() {
        return pessoaList;
    }

    public void limpar() {
        pessoa = new PessoaEntity();

        // Data/hora automática do cadastro
        pessoa.setDataHoraReg(new Date());

        editando = false;
    }

    public String novo() {
        limpar();
        return "cadastro?faces-redirect=true";
    }

    public PessoaEntity getPessoa() {
        return pessoa;
    }

    public void setPessoa(PessoaEntity pessoa) {
        this.pessoa = pessoa;
    }

    public PessoaEntity getPessoaSelecionada() {
        return pessoaSelecionada;
    }

    public void setPessoaSelecionada(PessoaEntity pessoaSelecionada) {
        this.pessoaSelecionada = pessoaSelecionada;
    }

    public boolean isEditando() {
        return editando;
    }

    public void setEditando(boolean editando) {
        this.editando = editando;
    }

    public String editar(PessoaEntity pessoa) {

        if (pessoa != null) {
            this.pessoa = pessoa;
            this.editando = true;
        }

        return "cadastro?faces-redirect=true";
    }

    public void salvar() {

        if (pessoa.getDataHoraReg() == null) {
            pessoa.setDataHoraReg(new Date());
        }

        if (pessoa.getId() == null) {
            pessoaFacade.create(pessoa);
        } else {
            pessoaFacade.edit(pessoa);
        }

        carregarLista();
        limpar();
    }

    public void visualizar(PessoaEntity pessoa) {

        if (pessoa != null && pessoa.getId() != null) {

            pessoaSelecionada =
                    pessoaFacade.find(pessoa.getId());
        }
    }

    public void excluir(PessoaEntity pessoa) {

        if (pessoa != null && pessoa.getId() != null) {

            PessoaEntity pessoaBanco =
                    pessoaFacade.find(pessoa.getId());

            if (pessoaBanco != null) {
                pessoaFacade.remove(pessoaBanco);
            }

            if (pessoaSelecionada != null
                    && pessoaSelecionada.getId().equals(pessoa.getId())) {

                pessoaSelecionada = null;
            }

            carregarLista();
        }
    }

    public String cancelar() {
        limpar();
        return "lista?faces-redirect=true";
    }

    /*
     * Mantido para não quebrar o formularioContato.xhtml
     */
    public void enviarContato() {
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public String getEmailContato() {
        return emailContato;
    }

    public void setEmailContato(String emailContato) {
        this.emailContato = emailContato;
    }

    public String getMensagemContato() {
        return mensagemContato;
    }

    public void setMensagemContato(String mensagemContato) {
        this.mensagemContato = mensagemContato;
    }
}