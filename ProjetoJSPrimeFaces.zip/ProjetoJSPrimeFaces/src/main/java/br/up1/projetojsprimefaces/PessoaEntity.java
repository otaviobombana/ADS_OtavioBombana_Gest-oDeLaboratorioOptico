package br.up1.projetojsprimefaces;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "pessoa")
public class PessoaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    // =========================================================
    // ID


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    // NOME
 

    @Column(name = "nome", nullable = false)
    private String nome;


    // CPF


    @Column(name = "cpf")
    private String cpf;

  
    // EMAIL
  

    @Column(name = "email", nullable = false)
    private String email;

 
    // SENHA


    @Column(name = "senha", nullable = false)
    private String senha;

   
    // TELEFONE


    @Column(name = "telefone")
    private String telefone;


    // CIDADE
    // Relacionamento ManyToOne (N:1)
   

    @ManyToOne
    @JoinColumn(name = "id_cidade", nullable = false)
    private CidadeEntity cidade;


    // DATA DE NASCIMENTO
   

    @Temporal(TemporalType.DATE)
    @Column(name = "datanascimento", nullable = false)
    private Date dataNascimento;


    // IDADE
  

    @Column(name = "idade", nullable = false)
    private Integer idade;


    // FUMANTE
 

    @Column(name = "fumante")
    private Boolean fumante;


    // CIDADANIA


    @Column(name = "cidadania")
    private String cidadania;


    // OBSERVAÇÃO
  

    @Column(name = "observacao")
    private String observacao;

   
    // DATA/HORA DO CADASTRO
   

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "datahorareg", nullable = false)
    private Date dataHoraReg;

  
    // CONSTRUTOR
  

    public PessoaEntity() {
    }


    // GETTERS E SETTERS


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public CidadeEntity getCidade() {
        return cidade;
    }

    public void setCidade(CidadeEntity cidade) {
        this.cidade = cidade;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public Boolean getFumante() {
        return fumante;
    }

    public void setFumante(Boolean fumante) {
        this.fumante = fumante;
    }

    public String getCidadania() {
        return cidadania;
    }

    public void setCidadania(String cidadania) {
        this.cidadania = cidadania;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Date getDataHoraReg() {
        return dataHoraReg;
    }

    public void setDataHoraReg(Date dataHoraReg) {
        this.dataHoraReg = dataHoraReg;
    }


    // EQUALS
   

    @Override
    public boolean equals(Object object) {

        if (!(object instanceof PessoaEntity)) {
            return false;
        }

        PessoaEntity other = (PessoaEntity) object;

        if ((this.id == null && other.id != null)
                || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }

        return true;
    }

    
    // HASHCODE
   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    // =========================================================
    // TOSTRING
    // =========================================================

    @Override
    public String toString() {
        return "PessoaEntity[ id=" + id + " ]";
    }
}