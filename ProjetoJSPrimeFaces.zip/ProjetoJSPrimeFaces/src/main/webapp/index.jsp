<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <title>Cadastro de Pessoas</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 40px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        .formulario,
        .lista {
            background-color: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #ccc;
        }

        h1,
        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #555;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background-color: #333;
            color: white;
            padding: 12px;
            text-align: left;
        }

        td {
            border: 1px solid #ddd;
            padding: 12px;
        }

        .excluir {
            background-color: #c62828;
            margin: 0;
        }

        .excluir:hover {
            background-color: #a51f1f;
        }

        #mensagem {
            text-align: center;
            font-weight: bold;
            margin-top: 15px;
            color: green;
        }

        .sem-registros {
            text-align: center;
            color: #777;
        }

    </style>

</head>

<body>

<div class="container">

    <!-- FORMUL�RIO -->

    <div class="formulario">

        <h1>Cadastro de Pessoas</h1>

        <form id="formCadastro">

            <label for="nome">Nome:</label>
            <input
                type="text"
                id="nome"
                placeholder="Digite o nome"
                required
            >

            <label for="cpf">CPF:</label>
            <input
                type="text"
                id="cpf"
                placeholder="Digite o CPF"
                required
            >

            <label for="email">E-mail:</label>
            <input
                type="email"
                id="email"
                placeholder="Digite o e-mail"
            >

            <label for="telefone">Telefone:</label>
            <input
                type="text"
                id="telefone"
                placeholder="Digite o telefone"
            >

            <label for="cidade">Cidade:</label>
            <input
                type="text"
                id="cidade"
                placeholder="Digite a cidade"
            >

            <button type="submit">
                Cadastrar
            </button>

        </form>

        <div id="mensagem"></div>

    </div>


    <!-- LISTA DE PESSOAS -->

    <div class="lista">

        <h2>Pessoas cadastradas</h2>

        <table>

            <thead>

                <tr>

                    <th>Nome</th>

                    <th>CPF</th>

                    <th>E-mail</th>

                    <th>Telefone</th>

                    <th>Cidade</th>

                    <th>A��o</th>

                </tr>

            </thead>

            <tbody id="listaPessoas">

                <tr>
                    <td colspan="6" class="sem-registros">
                        Nenhuma pessoa cadastrada.
                    </td>
                </tr>

            </tbody>

        </table>

    </div>

</div>


<script>

    // Lista onde vamos guardar as pessoas
    let pessoas = [];


    // Quando clicar em Cadastrar
    document
        .getElementById("formCadastro")
        .addEventListener("submit", function(event) {

            // Impede a p�gina de recarregar
            event.preventDefault();


            // Pegando os valores dos campos
            let nome = document.getElementById("nome").value;
            let cpf = document.getElementById("cpf").value;
            let email = document.getElementById("email").value;
            let telefone = document.getElementById("telefone").value;
            let cidade = document.getElementById("cidade").value;


            // Criando uma pessoa
            let pessoa = {

                nome: nome,

                cpf: cpf,

                email: email,

                telefone: telefone,

                cidade: cidade

            };


            // Adicionando a pessoa na lista
            pessoas.push(pessoa);


            // Limpando o formul�rio
            document
                .getElementById("formCadastro")
                .reset();


            // Mostrando mensagem
            document
                .getElementById("mensagem")
                .innerText = "Pessoa cadastrada com sucesso!";


            // Atualizando a tabela
            mostrarPessoas();

        });


    // Fun��o para mostrar as pessoas
    function mostrarPessoas() {

        let tabela = document.getElementById("listaPessoas");


        // Limpa a tabela
        tabela.innerHTML = "";


        // Verifica se n�o existem pessoas
        if (pessoas.length === 0) {

            let linha = document.createElement("tr");

            let coluna = document.createElement("td");

            coluna.colSpan = 6;

            coluna.className = "sem-registros";

            coluna.innerText = "Nenhuma pessoa cadastrada.";

            linha.appendChild(coluna);

            tabela.appendChild(linha);

            return;
        }


        // Percorre todas as pessoas
        for (let i = 0; i < pessoas.length; i++) {

            let pessoa = pessoas[i];


            // Cria uma linha
            let linha = document.createElement("tr");


            // Nome
            let colunaNome = document.createElement("td");

            colunaNome.innerText = pessoa.nome;

            linha.appendChild(colunaNome);


            // CPF
            let colunaCpf = document.createElement("td");

            colunaCpf.innerText = pessoa.cpf;

            linha.appendChild(colunaCpf);


            // E-mail
            let colunaEmail = document.createElement("td");

            colunaEmail.innerText = pessoa.email;

            linha.appendChild(colunaEmail);


            // Telefone
            let colunaTelefone = document.createElement("td");

            colunaTelefone.innerText = pessoa.telefone;

            linha.appendChild(colunaTelefone);


            // Cidade
            let colunaCidade = document.createElement("td");

            colunaCidade.innerText = pessoa.cidade;

            linha.appendChild(colunaCidade);


            // Coluna do bot�o
            let colunaAcao = document.createElement("td");


            // Criando bot�o
            let botaoExcluir = document.createElement("button");

            botaoExcluir.innerText = "Excluir";

            botaoExcluir.className = "excluir";


            // Quando clicar no bot�o
            botaoExcluir.onclick = function() {

                excluirPessoa(i);

            };


            // Coloca o bot�o na coluna
            colunaAcao.appendChild(botaoExcluir);


            // Coloca a coluna na linha
            linha.appendChild(colunaAcao);


            // Coloca a linha na tabela
            tabela.appendChild(linha);

        }

    }


    // Fun��o para excluir pessoa
    function excluirPessoa(index) {

        pessoas.splice(index, 1);

        mostrarPessoas();

        document
            .getElementById("mensagem")
            .innerText = "Pessoa exclu�da.";

    }

</script>

</body>

</html>